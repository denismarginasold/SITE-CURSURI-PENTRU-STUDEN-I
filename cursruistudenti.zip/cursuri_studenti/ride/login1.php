<?php
include 'connection.php';
if (isset($_SESSION["user_id"]) && $_SESSION["user_id"] != "") {
 
    redirect("dashboard.php");
}
$mode="";
$title = "Autentificare";
$mode = $_POST['mode'];
if ($mode == "loginare") {
    $username = trim($_POST['username']);
    $pass = trim($_POST['user_password']);

    if ($username == "" || $pass == "") { 
    } else {
        $sql = "SELECT * FROM user WHERE username = '$username' AND password = '$pass' ";
        $results= mysqli_query($db,$sql);
        if (!$results)
        die('Invalid querry:' .mysqli_error($db));
        else 
            {
$sql2 = mysqli_query($db,"SELECT user.id, user.username, user_data.nume, user_data.email, user_data.telefon ,user_data.Adresa, user_dash_text.content_text , user_right.redirect FROM USER, user_dash_text, user_data, user_right WHERE user.username = '$username' AND user.password = '$pass' AND USER.id =user_data.id_user AND user_right.id_user =USER.id AND user_right.right = user_dash_text.user_type_id;");
$myrow1=mysqli_fetch_array($sql2,MYSQLI_ASSOC);

$rows= mysqli_num_rows($sql2);
            if (count($rows) > 0) {
                $_SESSION["user_id"] = $myrow1["id"];
                $_SESSION["username"] = $myrow1["username"];
                $_SESSION["name"] = $myrow1["nume"];
                $_SESSION["email"] = $myrow1["email"];
                $_SESSION["titlu"] = $myrow1["content_text"];
                $_SESSION["telefon"] = $myrow1["telefon"];
                $_SESSION["Adresa"] = $myrow1["Adresa"];               
                $_SESSION["continut"] = $myrow1["content_text"];
               


                redirect($myrow1["redirect"]);
                exit;
            } 

        }
    }
    redirect("index.php");
}
include 'header.php';

?>
<style>
div.ex1 {
  border: 0px solid red; 
  margin-left: 30%;
  margin-bottom: 60px;
  margin-top: 90px;
}
div.ex2 {
  border: 0px solid red; 
  margin-left: 50px;
  margin-bottom: 50px;
  margin-top: 1px;

}
div.auto {
  border: 0px solid red;
  position: relative;
  padding-left: 40%
}
div.mydiv{
   content: "";
   background-color: #bfb;
   top: -50px;
   height: 50px;
   width: 50%;
   position: relative;
}
img.logo {
  border-radius: 50%;
  margin-top: 3px;
}
px
.product-image-gallery {
  background-color: #fefefe;
  padding: 1.9rem;
}
.pdp-product-image {
  margin-bottom: 20px;
}

.product-thumbs a {
  margin-left: 80px;
  margin-right: 80px;
  padding: 0 !important;
}
.product-thumbs a img {
  display: inline-block;
  max-width: 50%;
  margin-bottom: 1rem;
  border: solid 4px #fefefe77;
  border-radius: 0;
  box-shadow: 0 0 0 1px rgba(10, 10, 10, 0.384);
  line-height: 0;
  border-radius: 3px;
  width: 50px;
  height: 50px;
  border: none;
}
.sign-in-form {
  position: relative;
  padding: 100px 80px;
  border-radius: 30px;
  background-color: #51585f8e;
  border: 31px transparent rgba(124, 184, 184, 0.055); 
  margin-left: 20%;
  margin-right: 20%;
  margin-top: 5%;
  margin-bottom: 30%;

}
.sign-in-form h4 {
  color: rgb(0, 0, 0);
  margin-bottom: 1px;
  font-weight: 200;
  text-transform: uppercase;
}
.sign-in-form label {
  text-transform: uppercase;
  color: #000000;
  letter-spacing: 1px;
  font-weight: 200;
  margin-bottom: 1px;
}
.sign-in-form input {
  color: rgb(85, 82, 86);
}
.sign-in-form input:focus {
  opacity: 0.8;
}
.sign-in-form-username, .sign-in-form-password {
  border-radius: 30px;
  border: none;
  opacity: 0.1;
  transition: all ease 0.4s;
}
.sign-in-form-button {
  border: 1px solid #fff;
  color: #fff;
  background-color: transparent;
  text-transform: uppercase;
  letter-spacing: 1px;
  width: 60%;
  padding: 9px;
  transition: all ease 0.4s;
  margin-top: 10px;
  border-radius: 30px;
  margin-left: 20%
}
.sign-in-form-button:hover {
  background-color: #44c8ed;
  border-color: #44c8ed;
}
.show-password {
  width: 100%;
}
.show-password label {
  position: absolute;
}
.password-wrapper {
  position: relative;
}
.password + .unmask {
  position: relative;
  right: -101%;
  top: -35px;
  transform: translateY(-50%);
  text-indent: -9999px;
  width: 25px;
  height: 25px;
  background: rgb(129, 127, 127);
  border-radius: 40%;
  cursor: pointer;
  border: none;
  -webkit-appearance: none;
}
.password + .unmask:before {
  content: "";
  position: absolute;
  top: 4px;
  left: 4px;
  width: 17px;
  height: 17px;
  background: #e3e3e3;
  z-index: 1;
  border-radius: 50%;
}
input.test1{
  width: 250px;
}
.test2{
  width: 120px;
}
.password[type="text"] + .unmask:after {
  content: "";
  position: absolute;
  top: 6px;
  left: 6px;
  width: 13px;
  height: 13px;
  background: rgb(56, 55, 55);
  z-index: 2;
  border-radius: 50%;
}
</style>

<!-- Bara dreapta-->
<div class="off-canvas-wrapper">
<div class="off-canvas-wrapper-inner" data-off-canvas-wrapper>
<div class="off-canvas position-right reveal-for-large" id="my-info" data-off-canvas data-position="right">
<div class="row column">
</div>
</div>
<div class="off-canvas-content" data-off-canvas-content>
<div class="title-bar hide-for-large">
<div class="title-bar-right">
</div>
</div>
<!--Bara stanga-->

<div class="off-canvas-wrapper">
<div class="off-canvas-wrapper-inner" data-off-canvas-wrapper>
<div class="off-canvas position-left reveal-for-large" id="my-info" data-off-canvas data-position="left">
<div class="row column">
</div>
</div>
<div class="off-canvas-content" data-off-canvas-content>
<div class="title-bar hide-for-large">
<div class="title-bar-left">
</div>
</div>

<!--Meniu-->
<div class ="#mydiv">

    <div class="title-bar" data-responsive-toggle="responsive-menu" data-hide-for="medium">
  <button class="menu-icon" type="button" data-toggle="responsive-menu"></button>
  <div class="title-bar-title">Menu</div>
</div>
<div class="top-bar" id="responsive-menu">


  <div class="top-bar-left">
    <ul class="dropdown menu" data-dropdown-menu>
      <li> 
      <img  class="logo" alt="Avatar" src="static_images/logo1.jpg" width="30px" height="30px">
      </li>
      <li class="menu-text">Neautentificat</li>

    </ul>
  </div>

</div>


<form name="contact_form" id="contact_form" method="post" action="">
    
<div class="sign-in-form">
<h4 class="text-center">Sign In</h4>
<p class="hide"><input type="text" name="mode" value="loginare" ></p>
<div class="large-8 medium-8 small-12 columns">
<label for="sign-in-form-username">Username</label> 
<input type="text" name="username" value="user_admin" id="sign-in-form-username">
</div> 
<div class="large-8 medium-8 small-12 columns">  
<label for="sign-in-form-password">Password</label> 
<input type="password" name="user_password" value="user" id="sign-in-form-password" class="password">
<button class="unmask" type="button" title="Mask/Unmask password to check content"></button> 
</div>

<div class="large-8 medium-8 small-8 columns">
<input type="submit" class="sign-in-form-button " name="submit" value="SIGN IN">  
<input type="submit" class="sign-in-form-button " formaction="register.php" name="register" value="Register">  
</div>

</div>

</form>
<script src="js/vendor/jquery.js"></script>
<script src="js/vendor/what-input.js"></script>
<script src="js/vendor/foundation.js"></script>
<script src="js/show-password.js"></script>

<?php include 'footer.php'; ?>