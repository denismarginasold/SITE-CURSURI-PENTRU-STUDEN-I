<!doctype html>

<style>
div.ex1 {
  border: 0px solid red; 
  margin-left: 30%;
  margin-bottom: 60px;
  margin-top: 90px;

}
div.ex2 {
  border: 0px solid red; 
  margin-left: 50px;
  margin-bottom: 50px;
  margin-top: 1px;

}
div.auto {
  border: 0px solid red;
  position: relative;
  padding-left: 40%
}
div.mydiv{
   content: "";
   background-color: #bfb;
   top: -50px;
   height: 50px;
   width: 50%;
   position: relative;
}
img.logo {
  border-radius: 50%;
  margin-top: 3px;
}
.alerttext{
  margin: auto;
  width: 40%;
  padding: 5px;
  margin-top: 10px;
  border: 3px #CFF6D5;
  background-color: #A2EFAF;
  border-radius: 6rem;
  text-align: center;

}
.product-image-gallery {
  background-color: #fefefe;
  padding: 1.9rem;
}

.pdp-product-image {
  margin-bottom: 20px;
}

.product-thumbs a {
  margin-left: 80px;
  margin-right: 80px;
  padding: 0 !important;
}

.product-thumbs a img {
  display: inline-block;
  max-width: 50%;
  margin-bottom: 1rem;
  border: solid 4px #fefefe;
  border-radius: 0;
  box-shadow: 0 0 0 1px rgba(10, 10, 10, 0.2);
  line-height: 0;
  border-radius: 3px;
  width: 50px;
  height: 50px;
  border: none;
}
.sign-in-form {
  padding: 7rem 7.5em;
  border-radius: 2.5rem;
  background-color: #51585f8e;
  border: 3px solid rgba(194, 184, 184, 0.055); 
  margin-left: 30%;
  margin-right: 30%;
  margin-top: 90px;
}
.sign-in-form h4 {
  color: rgb(0, 0, 0);
  margin-bottom: 1rem;
  font-weight: 200;
  text-transform: uppercase;
}
.sign-in-form label {
  text-transform: uppercase;
  color: #000000;
  letter-spacing: 1px;
  font-weight: 200;
  margin-bottom: 1rem;
}
.sign-in-form input {
  color: rgb(212, 61, 61);
}
.sign-in-form input:focus {
  opacity: 0.8;
}
.sign-in-form-username, .sign-in-form-password {
  border-radius: 30px;
  border: none;
  opacity: 0.1;
  transition: all ease 0.4s;
}
.sign-in-form-button {
  border: 1px solid #fff;
  color: #fff;
  background-color: transparent;
  text-transform: uppercase;
  letter-spacing: 1px;
  width: 100%;
  padding: 1rem;
  transition: all ease 0.4s;
  margin-top: 10px;
  border-radius: 7.5rem;
}
.sign-in-form-button:hover {
  background-color: #44c8ed;
  border-color: #44c8ed;
}
.show-password {
  width: 100%;
}
.show-password label {
  position: absolute;
}
.password-wrapper {
  position: relative;
}
.password + .unmask {
  position: relative;
  right: -110%;
  top: -35px;
  transform: translateY(-50%);
  text-indent: -9999px;
  width: 25px;
  height: 25px;
  background: rgb(129, 127, 127);
  border-radius: 50%;
  cursor: pointer;
  border: none;
  -webkit-appearance: none;
}
.password + .unmask:before {
  content: "";
  position: absolute;
  top: 4px;
  left: 4px;
  width: 17px;
  height: 17px;
  background: #e3e3e3;
  z-index: 1;
  border-radius: 50%;
}
.password[type="text"] + .unmask:after {
  content: "";
  position: absolute;
  top: 6px;
  left: 6px;
  width: 13px;
  height: 13px;
  background: rgb(56, 55, 55);
  z-index: 2;
  border-radius: 50%;
}

</style>

<html class="no-js" lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/foundation.css">
    <link rel="stylesheet" href="css/app.css">
  </head>
  <body>
<!-- Bara dreapta-->
<div class="off-canvas-wrapper">
<div class="off-canvas-wrapper-inner" data-off-canvas-wrapper>
<div class="off-canvas position-right reveal-for-large" id="my-info" data-off-canvas data-position="right">
<div class="row column">
</div>
</div>
<div class="off-canvas-content" data-off-canvas-content>
<div class="title-bar hide-for-large">
<div class="title-bar-right">
</div>
</div>
<!--Bara stanga-->

<div class="off-canvas-wrapper">
<div class="off-canvas-wrapper-inner" data-off-canvas-wrapper>
<div class="off-canvas position-left reveal-for-large" id="my-info" data-off-canvas data-position="left">
<div class="row column">
</div>
</div>
<div class="off-canvas-content" data-off-canvas-content>
<div class="title-bar hide-for-large">
<div class="title-bar-left">
</div>
</div>

<!--Meniu-->
<div class ="#mydiv">

    <div class="title-bar" data-responsive-toggle="responsive-menu" data-hide-for="medium">
  <button class="menu-icon" type="button" data-toggle="responsive-menu"></button>
  <div class="title-bar-title">Menu</div>
</div>
<div class="top-bar" id="responsive-menu">


  <div class="top-bar-left">
    <ul class="dropdown menu" data-dropdown-menu>
      <li> 
      <img  class="logo" alt="Avatar" src="static_images/logo1.jpg" width="30px" height="30px">
      </li>
      <li class="menu-text">Neautentificat</li>

    </ul>
  </div>
  <div class="top-bar-right">
    <ul class="menu">
      <li><input type="search" placeholder="Search"></li>
      <li><button type="button" class="button">Search</button></li>
    </ul>

  </div>
</div>
<!-- LOGARE---> 
<form method="post" action="dashboardadauga.php">
    <div class="sign-in-form">
      <h4 class="text-center">Register</h4>
      <label for="sign-in-form-username">Username</label>
      <div class="large-8 medium-8 small-12 columns">
      <input type="text" name="username" value="" class="unmask" id="sign-in-form-username">
      </div>
      <label for="sign-in-form-password">Password</label>
      <div class="large-8 medium-8 small-12 columns">
      <input type="password" name="parola" value="" placeholder="Enter Password" id="sign-in-form-password" class="password">
      <button class="unmask" type="button" title="Mask/Unmask password to check content">Unmask</button>
      </div>
      <label for="sign-in-form-email">E-mail</label>
      <div class="large-8 medium-8 small-12 columns">
      <input type="text" name="email" value="" class="unmask" id="sign-in-form-username">
      </div>

      
      <button  type="submit" formaction="register2.php" class="sign-in-form-button">Register</button>
      <button  type="submit" formaction="login1.php" class="sign-in-form-button">Sign In</button>
      <script src="js/show-password.js"></script>
    </div>
  </form>






    <script src="js/vendor/jquery.js"></script>
    <script src="js/vendor/what-input.js"></script>
    <script src="js/vendor/foundation.js"></script>
    <script src="js/show-password.js"></script>

</div>

  </body>
</html>
