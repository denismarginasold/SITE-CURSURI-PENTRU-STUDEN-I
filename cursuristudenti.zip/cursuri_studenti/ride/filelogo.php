


<?php
 require_once("connection.php");

if (!isset($_SESSION["user_id"]) || $_SESSION["user_id"] == "") {

    redirect("login1.php");
}
include 'footer.php'; 



$nume=$_SESSION["username"];
$id_user=$_SESSION["user_id"];
$npoza=$_FILES["file"]["name"];
$db=mysqli_connect("127.0.0.1","root","");
mysqli_select_db($db,"licienta");
//echo $nume;
//echo $id_user;
  if ($_FILES["file"]["error"] > 0)
			{
			echo "Return Code: " . $_FILES["file"]["error"] . "<br />";
			}
		else
    {
	
	
			//echo "Fisier Uploadat: " . $_FILES["file"]["name"] . "<br />";
			//echo "Tipul: " . $_FILES["file"]["type"] . "<br />";
			//echo "Dimensiunea: " . ($_FILES["file"]["size"] / 1024) . " Kb<br />";
			//echo "Fisierul temporar: " . $_FILES["file"]["tmp_name"] . "<br />";

						$extension = explode("/", $_FILES["file"]["type"]);



			if (file_exists("static_images/".$id_user))	
{		  
			if (file_exists("static_images/".$id_user."/".$nume.".".$extension[1]))

              { 
								//echo "Poza ".$nume." a fost creat cu succes"; 
								move_uploaded_file($_FILES["file"]["tmp_name"],"static_images/".$id_user."/".$nume.".".$extension[1]);

								$imagine ="static_images/".$id_user."/".$nume.".".$extension[1];
								$sql="UPDATE user_data,user SET user_data.logo_user='$imagine' WHERE user_data.id_user =user.id AND user.username='$nume';";
				   $result= mysqli_query($db,$sql);
					if (!$result)
					 die('Invalid querry:' .mysqli_error($db));
					 
							}  }
				else {
							//Creaza folder cu numele id user!	
							if(mkdir("static_images/".$id_user ."/" , 0777))  
									 {
										 //echo "Directorul ".$id_user." a fost creat cu succes"; 
										 //echo "Poza ".$nume." a fost adaugata cu succes"; 
										 move_uploaded_file($_FILES["file"]["tmp_name"],"static_images/".$id_user."/".$nume.".".$extension[1]);
										 $imagine ="static_images/".$id_user."/".$nume.".".$extension[1];
										 $sql="UPDATE user_data,user SET user_data.logo_user='$imagine' WHERE user_data.id_user =user.id AND user.username='$nume';";
										 $result= mysqli_query($db,$sql);
										if (!$result)
										 die('Invalid querry:' .mysqli_error($db));
									}
							else {echo"Nu s-a putut crea folder pentru acest user";}
				}


              
		}
if (file_exists("static_images/".$id_user)) 
{
//echo "am facut";
$extension = explode("/", $_FILES["file"]["type"]);
$filename ="static_images/".$id_user."/".$nume.".".$extension[1];
$width = 250;
$height = 250;
//header('Content-Type: image/jpeg');
list($width_orig, $height_orig) = getimagesize($filename);
$image_p = imagecreatetruecolor($width, $height);
$image_p = imagecreate ( $width , $height );
$image = imagecreatefromjpeg($filename);
imagecopyresampled($image_p, $image, 0, 0, 0, 0, $width, $height, $width_orig, $height_orig);
imagecopyresized($image_p, $image, 0, 0, 0, 0, $width, $height, $width_orig, $height_orig) ;

imagejpeg($image_p, $filename);}
Redirect('profiluser.php');
?> 