<?php
 require_once("connection.php");

if (!isset($_SESSION["user_id"]) || $_SESSION["user_id"] == "") {

    redirect("login1.php");
}




include 'footer.php'; 

$nume=$_POST["nume"];
$id_user=$_SESSION["user_id"];
$npoza=$_FILES["file"]["name"];
$db=mysqli_connect("127.0.0.1","root","");
mysqli_select_db($db,"licienta");
$eroare="Eroare :";

$sqltry= "SELECT cursuri.numec FROM cursuri,imagini_curs WHERE cursuri.id ='$idd' AND imagini_curs.id_curs=cursuri.id;";
$result= mysqli_query($db,$sqltry);
if (!$result)
die('Invalid querry:' .mysqli_error($db));
else {
	while ($myrow=mysqli_fetch_array($result,MYSQLI_ASSOC))
	{   
				if ($myrow['numec'] == $nume)
				$eroare = $eroare + " Numele a fost folosit. ";
				Redirect('request.php?$eroare='.$eroare.'');
   }}



  if ($_FILES["file"]["error"] > 0)
			{
			echo "Return Code: " . $_FILES["file"]["error"] . "<br />";
			}
		else
    {
	
	
			//echo "Fisier Uploadat: " . $_FILES["file"]["name"] . "<br />";
			//echo "Tipul: " . $_FILES["file"]["type"] . "<br />";
			//echo "Dimensiunea: " . ($_FILES["file"]["size"] / 1024) . " Kb<br />";
			//echo "Fisierul temporar: " . $_FILES["file"]["tmp_name"] . "<br />";

			$extension = explode("/", $_FILES["file"]["type"]);
			if (file_exists("images/".$id_user))	
{		    
			if (file_exists("images/".$id_user."/".$nume.".".$extension[1]))
			      {
					   $eroare = $eroare+" Imaginea exista deja! Incearca sa schimbi numele !. ";
              }
              else
              { 
								move_uploaded_file($_FILES["file"]["tmp_name"],"images/".$id_user."/".$nume.".".$extension[1]);
								move_uploaded_file($_FILES["file"]["tmp_name"],'C:/xampp/htdocs/ride/temporary/test.png');
								$imaginec ="images/".$id_user."/".$nume.".".$extension[1];
								$dest="C:/xampp/htdocs/ride/images/".$id_user."/out";
								$sourc="C:/xampp/htdocs/ride/images/".$id_user."/".$nume.".".$extension[1];
								$comd ='cd C:\Program Files (x86)\Tesseract-OCR & tesseract.exe C:/xampp/htdocs/ride/images/'.$id_user.'/"'.$nume.'".'.$extension[1].' C:/xampp/htdocs/ride/images/'.$id_user.'/out -l ron';
								//echo "comanda : " ;
								echo $comd;
								shell_exec($comd);
								$file = file_get_contents('images/'.$id_user.'/out.txt');
								$textc = $file;
								//echo "Textul images/".$id_user."/out.txt : ";echo $textc;
								$sql="INSERT INTO cursuri (numec,textc,cursuri.user_id) VALUES ('$nume','$textc','$id_user');";
								$sql2 ="INSERT INTO imagini_curs(id_curs,imagini_curs.imaginec) VALUES ((SELECT cursuri.id FROM cursuri  WHERE numec='$nume'),'$imaginec');";
								//unlink('images/'.$id_user.'/out.txt');
								//$my_file = 'temporary/out.txt';
								//$handle = fopen($my_file, 'w') or die('Cannot open file:  '.$my_file);
								//fwrite($handle, 'Error');
								//fclose($handle);

					 $result1= mysqli_query($db,$sql);
					 $result2= mysqli_query($db,$sql2);
					if ((!$result1) or (!$result2))
					 die('Invalid querry:' .mysqli_error($db));
					 
							}  }
				else {

							if(mkdir("images/".$id_user ."/" , 0777))  
									 {
										move_uploaded_file($_FILES["file"]["tmp_name"],"images/".$id_user."/".$nume.".".$extension[1]);
										move_uploaded_file($_FILES["file"]["tmp_name"],'C:/xampp/htdocs/ride/temporary/test.png');
										$imaginec ="images/".$id_user."/".$nume.".".$extension[1];
										$dest="C:/xampp/htdocs/ride/images/".$id_user."/out";
										$sourc="C:/xampp/htdocs/ride/images/".$id_user."/".$nume.".".$extension[1];
										$comd ='cd C:\Program Files (x86)\Tesseract-OCR & tesseract.exe C:/xampp/htdocs/ride/images/'.$id_user.'/"'.$nume.'".'.$extension[1].' C:/xampp/htdocs/ride/images/'.$id_user.'/out -l ron';
										//echo "comanda : " ;
										//echo $comd;
										shell_exec($comd);
										$file = file_get_contents('images/'.$id_user.'/out.txt');
										$textc = $file;
										//echo "Textul images/".$id_user."/out.txt : ";echo $textc;
										$sql="INSERT INTO cursuri (numec,textc,cursuri.user_id) VALUES ('$nume','$textc','$id_user');";
										$sql2 ="INSERT INTO imagini_curs(id_curs,imagini_curs.imaginec) VALUES ((SELECT cursuri.id FROM cursuri  WHERE numec='$nume'),'$imaginec');";
										//unlink('images/'.$id_user.'/out.txt');
										//$my_file = 'temporary/out.txt';
										//$handle = fopen($my_file, 'w') or die('Cannot open file:  '.$my_file);
										//fwrite($handle, 'Error');
										//fclose($handle);
		
							 $result1= mysqli_query($db,$sql);
							 $result2= mysqli_query($db,$sql2);
							if ((!$result1) or (!$result2))
							 die('Invalid querry:' .mysqli_error($db));
									}
							else {echo"Nu s-a putut crea folder pentru acest user";}
				}


              
		}
		unlink('images/'.$id_user.'/out.txt');
		Redirect('request.php');
?> 