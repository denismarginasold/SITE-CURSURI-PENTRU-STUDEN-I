
<?php

require_once("connection.php");

if (!isset($_SESSION["user_id"]) || $_SESSION["user_id"] == "") {

    redirect("login1.php");
}


?>
<?php 
$numeu =$_SESSION["username"];
$sql="SELECT user.id, user.username, user_data.nume, user_data.email, user_data.telefon ,user_data.Adresa, user_dash_text.content_text , user_right.redirect, user_data.logo_user FROM USER, user_dash_text, user_data, user_right WHERE  USER.id =user_data.id_user AND user_right.id_user =USER.id AND user_right.right = user_dash_text.user_type_id AND (user.username='$numeu' OR user_data.email='$numeu');";


$result= mysqli_query($db,$sql);


if (!$result)
 die('Invalid querry:' .mysqli_error($db));
 else 
 {
     while ($myrow=mysqli_fetch_array($result,MYSQLI_ASSOC))
     {
      $idi = $myrow["id"];
      $usernamei = $myrow["username"];
      $numei = $myrow["nume"];
      $emaili = $myrow["email"];
      $telefoni = $myrow["telefon"];
      $adresai = $myrow["Adresa"];
      $logoi = $myrow["logo_user"];

 }
 }

?>

<?php include 'footer.php'; ?>
<style>
div.ex1 {
  border: 0px solid red; 
  margin-left: 30%;
  margin-bottom: 60px;
  margin-top: 90px;

}
div.ex2 {
  border: 0px solid red; 
  margin-left: 50px;
  margin-bottom: 50px;
  margin-top: ;

}
div.auto {
  border: 0px solid red;
  position: relative;
  padding-left: 40%
}
div.mydiv{
   content: "";
   background-color: #bfb;
   top: -100px;
   height: 100px;
   width: 100%;
   position: absolute;
}
img.logo {
  border-radius: 50%;
  margin-top: 3px;
}
px
.product-image-gallery {
  background-color: #fefefe;
  padding: 1.9rem;
}

.pdp-product-image {
  margin-bottom: 20px;
}

.product-thumbs a {
  margin-left: 8px;
  margin-right: 8px;
  padding: 0 !important;
}

.product-thumbs a img {
  display: inline-block;
  max-width: 100%;
  margin-bottom: 1rem;
  border: solid 4px #fefefe;
  border-radius: 0;
  box-shadow: 0 0 0 1px rgba(10, 10, 10, 0.2);
  line-height: 0;
  border-radius: 3px;
  width: 50px;
  height: 50px;
  border: none;
}

.tableback{
     margin-top: 5%;
     margin-left: 2%;
     margin-right :2%;
     border: solid 1px #51585f8e;
     background-color:  #51585f8e;
     border-radius: 2rem;
}
.adjs{
     margin-top: 5%;
     margin-right :20rem;
     border: solid 1px #51585f8e;
     background-color:  #51585f8e;
}
.ajsleft{
  padding-left:20px;
  margin-left :20px;
}
.currentb{
  border: solid 1px #51585f8e;
  background-color:  #51585f8e;
}
.table th{
    background-color:  #51585f8e;
    border: solid 1px #DDEEEE;
    padding: 15px;
    text-align: center;

}
.adjs{
     margin-top: 5%;
     margin-right :20rem;
     border: solid 1px #51585f8e;
     background-color:  #51585f8e;
     margin-bottom :5%;
}
</style>

<html class="no-js" lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/foundation.css">
    <link rel="stylesheet" href="css/app.css">
  </head>
  <body>
<!-- Bara dreapta-->
<div class="off-canvas-wrapper">
<div class="off-canvas-wrapper-inner" data-off-canvas-wrapper>
<div class="off-canvas position-right reveal-for-large" id="my-info" data-off-canvas data-position="right">
<div class="row column">
</div>
</div>
<div class="off-canvas-content" data-off-canvas-content>
<div class="title-bar hide-for-large">
<div class="title-bar-right">
</div>
</div>
<!--Bara stanga-->

<div class="off-canvas-wrapper">
<div class="off-canvas-wrapper-inner" data-off-canvas-wrapper>
<div class="off-canvas position-left reveal-for-large" id="my-info" data-off-canvas data-position="left">
<div class="row column">
</div>
</div>
<div class="off-canvas-content" data-off-canvas-content>
<div class="title-bar hide-for-large">
<div class="title-bar-left">
</div>
</div>

<!--Meniu-->
<div class ="#mydiv">

    <div class="title-bar" data-responsive-toggle="responsive-menu" data-hide-for="medium">
  <button class="menu-icon" type="button" data-toggle="responsive-menu"></button>
  <div class="title-bar-title">Cursuri</div>
</div>
<div class="top-bar" id="responsive-menu">


  <div class="top-bar-left">
    <ul class="dropdown menu" data-dropdown-menu>
      <li> 
      <img  class="logo" alt="Avatar" src=<?php $nume=$_SESSION["username"];$id_user=$_SESSION["user_id"];     $imagine ="static_images/".$id_user."/".$nume.".jpeg";     if (file_exists($logoi)) {echo $logoi;}      else {echo "static_images/logo1.jpg";} ?> width="40px" height="40px"></li>
      <li class="has-submenu">
      <a href="profiluser.php" class="menu-text"><?php echo$_SESSION["username"] ?>   </a>
      <ul class="submenu menu vertical" data-submenu>
             <li><a href="logout.php">Delogare</a></li>
             <li><a href="profiluser.php">Profil</a></li>
      </ul>
      </li>
      <li class="has-submenu">
        <a href="dashboard.php">Cursuri</a>
        <ul class="submenu menu vertical" data-submenu>
          <li><a href="dashboard.php">Incarca Curs</a></li>
          <li><a href="request.php">Cursurile Tale</a></li>
        </ul>
      </li>
<?php
$numeu =$_SESSION["username"];
$sqlright  ="SELECT user_right.right FROM user_right, user WHERE user.id= user_right.id_user AND user.username='$numeu'";
$resultright= mysqli_query($db,$sqlright);
$row= mysqli_fetch_array($resultright);
$rightstring = $row['right'];
//echo $rightstring;
if ($rightstring=='admin'){

  echo "      <li class=\"has-submenu\">\n";
  echo "        <a >Admin</a>\n";
  echo "        <ul class=\"submenu menu vertical\" data-submenu>\n";
  echo "          <li><a href=\"dashboardviewc.php\">Afisare Cursuri</a></li>\n";
  echo "          <li><a href=\"dashboardview.php\">Afisare Utilizatori</a></li>\n";
  echo "          <li><a href=\"dashboardadauga.php\">Incarca Utilizatori</a></li>\n";
  echo "          <li><a href=\"dashboarddelet.php\">Sterge Utilizatori</a></li>\n";
  echo "          <li><a href=\"dashboardsearch.php\">Cauta Utilizatori</a></li>\n";
  echo "          <li><a href=\"dashboardright.php\">Drepturi Utilizatori</a></li>\n";
  echo "        </ul>\n";
  echo "      </li>";
  }
?>
    </ul>
  </div>
  <?php
     $idsearch ="";
     echo '<form action=search.php?'.$idsearch.' method="post" enctype="multipart/form-data">';
     echo '<div class="top-bar-right">';
     echo '<ul class="menu">';

     // $idsearch= $_POST["search"]; 

      echo "<li><input type=search id=search name=search placeholder=Search></li>";
      echo '<li><button  type="submit" class=button>Search</button></li>';
      ?>
    </ul>

  </div>
  </form>
</div>
<!--////Meniu-->

<!--View-->
<?php
$start=0;
$limit=3;
$id=1;
if(isset($_GET['id']))
{
$id=$_GET['id'];
$start=($id-1)*$limit;
}
$sqlv="SELECT user.username, cursuri.numec, cursuri.textc,imagini_curs.imaginec FROM imagini_curs,user,cursuri WHERE user.id =cursuri.user_id AND cursuri.id = imagini_curs.id_curs LIMIT $start, $limit;"; 
$resultv= mysqli_query($db,$sqlv);
 

if (!$resultv)
 die('Invalid querry:' .mysqli_error($db));
 else 
 {





  echo "<div class=tableback>";
  echo "<table class='adjs table' border=1 cellpadding=2>";
  echo "
  <tr>
      <th>User</th>
      <th>Nume curs</th>
      <th>Text</th>
      <th>Imagine</th>
  </tr>
";
     while ($myrow=mysqli_fetch_array($resultv,MYSQLI_ASSOC))
     {echo "<tr><td>";
      echo $myrow["username"];
      echo "</td><td>";
      echo $myrow["numec"];
      echo "</td><td>";
      echo $myrow["textc"];
      echo "</td><td>";
      echo $myrow["imaginec"];
      echo "</td></tr>"; }
  echo "</table>";


$rows= mysqli_num_rows(mysqli_query($db,"SELECT user.username, cursuri.numec, cursuri.textc,imagini_curs.imaginec FROM imagini_curs,user,cursuri WHERE user.id =cursuri.user_id AND cursuri.id = imagini_curs.id_curs;" ));
$total=ceil($rows/$limit);
if($id>1)
{
echo "<a href='?id=".($id-1)."' class='button ajsleft'>PREVIOUS </a>";
}
if($id!=$total)
{
echo "<a href='?id=".($id+1)."' class='button ajsleft'> NEXT</a>";
}

echo "<ul class='page'>";
for($i=1;$i<=$total;$i++)
{
if($i==$id) { echo "<a href='?id=".$i."' class='currentb button'>".$i."</a>"; }

else { echo "<a href='?id=".$i."' class='button'>".$i."</a>"; }
}
echo "</ul>";
echo "</div>";
 }


?>

    <script src="js/vendor/jquery.js"></script>
    <script src="js/vendor/what-input.js"></script>
    <script src="js/vendor/foundation.js"></script>
    <script src="js/app.js"></script>

</div>

  </body>
</html>
