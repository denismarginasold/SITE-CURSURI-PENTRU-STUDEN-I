<?php
 require_once("connection.php");

if (!isset($_SESSION["user_id"]) || $_SESSION["user_id"] == "") {

    redirect("login1.php");
}




include 'footer.php'; 


$idd = $_GET['del'];
echo $idd;
$id_user=$_SESSION["user_id"];
$db=mysqli_connect("127.0.0.1","root","");
mysqli_select_db($db,"licienta");

$imagesql = "SELECT imagini_curs.imaginec,cursuri.numec FROM cursuri,imagini_curs WHERE cursuri.id ='$idd' AND imagini_curs.id_curs=cursuri.id;";
$imageres = mysqli_query($db,$imagesql);
if (!$imageres){
	die('Invalid querry:' .mysqli_error($db));}
else{
while($myrow =mysqli_fetch_array($imageres,MYSQLI_ASSOC)){
$image =$myrow['imaginec'];echo $myrow['imaginec'];
$numec = $myrow['numec'];echo $myrow['numec'];
}}
//$imagine ="images/".$id_user."/".$nume.".".$extension[1];

                unlink($image);
                $sql="DELETE imagini_curs,cursuri FROM imagini_curs,cursuri WHERE imagini_curs.id_curs=cursuri.id AND cursuri.numec='$numec';";
				   $result= mysqli_query($db,$sql);
					if (!$result){
					die('Invalid querry:' .mysqli_error($db));}
					else {echo "  cursuri.id = $idd";}
					 
							  


		
		Redirect('request.php');
?> 