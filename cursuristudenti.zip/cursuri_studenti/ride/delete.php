<?php
require_once("connection.php");

if (!isset($_SESSION["user_id"]) || $_SESSION["user_id"] == "") {

    redirect("login1.php");
}
$nume1 =$_SESSION["username"];
$sql="SELECT user.id, user.username, user_data.nume, user_data.email, user_data.telefon ,user_data.Adresa, user_dash_text.content_text , user_right.redirect, user_data.logo_user 
FROM USER, user_dash_text, user_data, user_right 
WHERE  USER.id =user_data.id_user AND user_right.id_user =USER.id AND user_right.right = user_dash_text.user_type_id AND (user.username='$nume1' OR user_data.email='$nume1');";


$result= mysqli_query($db,$sql);


if (!$result)
 die('Invalid querry:' .mysqli_error($db));
 else 
 {
     while ($myrow=mysqli_fetch_array($result,MYSQLI_ASSOC))
     {
      $idi = $myrow["id"];
      $usernamei = $myrow["username"];
      $numei = $myrow["nume"];
      $emaili = $myrow["email"];
      $telefoni = $myrow["telefon"];
      $adresai = $myrow["Adresa"];
      $logoi = $myrow["logo_user"];

 }
 } 



								//$sql="UPDATE user_data,user SET user_data.logo_user='$imagine' WHERE user_data.id_user =user.id AND user.username='$nume';";
                                //$result= mysqli_query($db,$sql);
                                ///delete(""static_images/".$id_user."/".$nume.".".$extension[1]););
                                $extension = explode("static_images/".$id_user."/",$nume);
                                echo "static_images/".$id_user."/".$nume.".".$extension[1];
                                //Redirect('galerie.php');
                                
?>