-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               10.1.38-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Version:             10.1.0.5492
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Dumping database structure for licienta
CREATE DATABASE IF NOT EXISTS `licienta` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `licienta`;

-- Dumping structure for procedure licienta.adauga_user
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `adauga_user`(
	IN `$Username` CHAR(50),
	IN `$Parola` CHAR(50),
	IN `$Nume` CHAR(50),
	IN `$Email` CHAR(50),
	IN `$Telefon` CHAR(50),
	IN `$Adresa` CHAR(50)

)
    COMMENT 'CALL adauga_user(''$Username'',''$Parola'',''$Nume'',''$Email'',''$Telefon'',''$Adresa'');'
BEGIN

INSERT INTO user(id,username,user.PASSWORD) VALUES(id,$Username,$Parola);
INSERT INTO user_data(id_user) SELECT user.id FROM user  WHERE username=$Username;
UPDATE user_data SET user_data.nume=$Nume,user_data.Email=$Email,user_data.telefon=$Telefon,user_data.Adresa=$Adresa WHERE user_data.id_user IN (SELECT user.id FROM user WHERE user.username =$Username );
INSERT INTO user_right(id_user)  SELECT user.id FROM user  WHERE username=$Username; 

END//
DELIMITER ;

-- Dumping structure for procedure licienta.cautare
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `cautare`(
	IN `nume` CHAR(50)





)
BEGIN

SELECT user.id, user.username, user_data.nume, user_data.email, user_data.telefon ,user_data.Adresa, user_dash_text.content_text , user_right.redirect,user_right.right, user_data.logo_user  FROM USER, user_dash_text, user_data, user_right WHERE  USER.id =user_data.id_user AND user_right.id_user =USER.id AND user_right.right = user_dash_text.user_type_id AND (user.username=nume OR user_data.email=nume);


END//
DELIMITER ;

-- Dumping structure for table licienta.cursuri
CREATE TABLE IF NOT EXISTS `cursuri` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `numec` char(50) NOT NULL,
  `textc` varchar(3000) NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_user` (`user_id`),
  CONSTRAINT `FK_cursuri_user` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=156 DEFAULT CHARSET=latin1;

-- Dumping data for table licienta.cursuri: ~0 rows (approximately)
/*!40000 ALTER TABLE `cursuri` DISABLE KEYS */;
REPLACE INTO `cursuri` (`id`, `numec`, `textc`, `user_id`) VALUES
	(155, 'user_admin_205', 'Cartea de faÅ£Äƒ reproduce Ã®n mod cÃ¢t se poate de fidel, atÃ¢t ca ordonare\na materiei, cÃ¢t ÅŸi ca Ã®ntindere, lecÅ£iile de Modelare ÅŸi Programare MatematicÄƒ\npe care autorul le Å£ine la Facultatea de ÅžtiinÅ£e, Universitatea de Nord, Baia\nMare. Cartea este destinatÄƒ studenÅ£ilor de matematicÄƒ, informaticÄƒ ÅŸi infor-\nmaticÄƒ economicÄƒ ÅŸi le oferÄƒ o introducere Ã®n problematica de bazÄƒ a modelÄƒrii\nÅŸi programÄƒrii (optimizÄƒrii) matematice.\n\nModelarea matematicÄƒ este procesul de utilizare a diferite structuri mate-\nmatice - grafuri, ecuaÅ£ii, diagrame, etc. - pentru reprezentarea situaÅ£iilor reale.\nModelul furnizeazÄƒ o abstractizare care reduce o problemÄƒ la caracteristicele ei\nesenÅ£iale. Modelul poate fi deci definit ca fiind o oglindÄƒ a realitÄƒÅ£ii care reflectÄƒ\nfidel doar aspectele relevante pentru fenomenul studiat.\n\nUn model matematic foloseÅŸte limbajul matematic pentru a descrie un anu-\nmit fenomen. Rolul social al modelelor matematice este extrem de mare, chiar\nimposibil de evaluat. Modelele matematice sunt folosite Ã®r1 particular Ã®n ÅŸtiinÅ£ele\nnaturale ÅŸi Ã®n inginerie (ca de exemplu fizicÄƒ, biologie, electrotehnica), dar de\nasemenea ÅŸi Ã®n ÅŸtiinÅ£ele sociale (ca de exemplu ÅŸtiinÅ£e economice, sociologie,\nÅŸtiinÅ£e politice).\n\n', 1);
/*!40000 ALTER TABLE `cursuri` ENABLE KEYS */;

-- Dumping structure for procedure licienta.delete_user
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `delete_user`(
	IN `Param` CHAR(50)

)
BEGIN
DECLARE y INT DEFAULT 0;
SET y = (SELECT user.id FROM user where user.username= Param);
DELETE FROM user_right WHERE user_right.id_user = y;
DELETE FROM user_data WHERE user_data.id_user = y;
DELETE FROM user WHERE user.id = y;


END//
DELIMITER ;

-- Dumping structure for table licienta.imagini_curs
CREATE TABLE IF NOT EXISTS `imagini_curs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `imaginec` varchar(100) NOT NULL,
  `id_curs` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_curs` (`id_curs`),
  CONSTRAINT `FK_imagini_curs_cursuri` FOREIGN KEY (`id_curs`) REFERENCES `cursuri` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=93 DEFAULT CHARSET=latin1;

-- Dumping data for table licienta.imagini_curs: ~0 rows (approximately)
/*!40000 ALTER TABLE `imagini_curs` DISABLE KEYS */;
REPLACE INTO `imagini_curs` (`id`, `imaginec`, `id_curs`) VALUES
	(92, 'images/1/user_admin_205.png', 155);
/*!40000 ALTER TABLE `imagini_curs` ENABLE KEYS */;

-- Dumping structure for procedure licienta.update_user
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_user`(
	IN `$id` INT,
	IN `$Username` CHAR(50),
	IN `$Parola` CHAR(50),
	IN `$Nume` CHAR(50),
	IN `$Email` CHAR(50),
	IN `$Telefon` CHAR(50),
	IN `$Adresa` CHAR(50),
	IN `$Logo` CHAR(50)







)
BEGIN
UPDATE user SET user.username =$Username,user.password= $Parola WHERE user.id = $id;
UPDATE user_data
SET user_data.nume=$Nume,user_data.Email=$Email,user_data.telefon=$Telefon,user_data.Adresa=$Adresa,user_data.logo_user=$Logo
WHERE user_data.id_user = $id;

END//
DELIMITER ;

-- Dumping structure for table licienta.user
CREATE TABLE IF NOT EXISTS `user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

-- Dumping data for table licienta.user: ~12 rows (approximately)
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
REPLACE INTO `user` (`id`, `username`, `password`) VALUES
	(1, 'user_admin', 'admin'),
	(2, 'user_user', 'user'),
	(4, 'Andrei', 'andrei'),
	(5, '', ''),
	(7, 'Denis', 'denis'),
	(8, 'user2', 'user2'),
	(9, 'Striker', 'striker'),
	(10, 'Striker2', 'striker2'),
	(11, 'sadasda', 'daaaaa'),
	(12, 'saaa', 'dadadad'),
	(13, 'dasda', 'dsada'),
	(14, 'dasdad', 'dssadad');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;

-- Dumping structure for table licienta.user_dash_text
CREATE TABLE IF NOT EXISTS `user_dash_text` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_type_id` enum('admin','user') NOT NULL DEFAULT 'user',
  `content_text` enum('Welcome admin','Welcome user') NOT NULL DEFAULT 'Welcome user',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- Dumping data for table licienta.user_dash_text: ~2 rows (approximately)
/*!40000 ALTER TABLE `user_dash_text` DISABLE KEYS */;
REPLACE INTO `user_dash_text` (`id`, `user_type_id`, `content_text`) VALUES
	(1, 'user', 'Welcome user'),
	(2, 'admin', 'Welcome admin');
/*!40000 ALTER TABLE `user_dash_text` ENABLE KEYS */;

-- Dumping structure for table licienta.user_data
CREATE TABLE IF NOT EXISTS `user_data` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nume` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `telefon` varchar(50) NOT NULL,
  `Adresa` varchar(50) NOT NULL,
  `id_user` int(10) unsigned NOT NULL,
  `logo_user` varchar(50) NOT NULL DEFAULT 'static_image/logo1.jpg',
  PRIMARY KEY (`id`),
  KEY `id_user` (`id_user`),
  CONSTRAINT `FK_user_data_user` FOREIGN KEY (`id_user`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

-- Dumping data for table licienta.user_data: ~11 rows (approximately)
/*!40000 ALTER TABLE `user_data` DISABLE KEYS */;
REPLACE INTO `user_data` (`id`, `nume`, `email`, `telefon`, `Adresa`, `id_user`, `logo_user`) VALUES
	(1, 'sadas', 'Denis', '312312', 'dsadas', 2, 'static_image/logo1.jpg'),
	(4, 'Andrei1231', 'Andrei@gmail.com', '2312431', 'Str Marceanului', 1, 'static_images/1/user_admin.jpeg'),
	(6, '', 'andrei@gmail.com', '', '', 4, 'static_image/logo1.jpg'),
	(7, '', '', '', '', 5, 'static_image/logo1.jpg'),
	(9, 'dsadsada', 'dsadsadaa', 'dasdad', 'dadada', 7, 'static_images/7/Denis.jpeg'),
	(10, 'dsadasda', 'user@gmail.com', 'dsadas', 'dsadasda', 8, 'static_images/8/user2.jpeg'),
	(11, '', 'striker@gmail.com', '', '', 9, 'static_image/logo1.jpg'),
	(12, '', 'andrei@gmail.com', '', '', 10, 'static_image/logo1.jpg'),
	(13, '', 'andrei@gmail.com', '', '', 11, 'static_image/logo1.jpg'),
	(14, '', 'andrei@gmail.com', '', '', 12, 'static_image/logo1.jpg'),
	(15, '', 'andrei@gmail.com', '', '', 13, 'static_image/logo1.jpg'),
	(16, '', 'andrei@gmail.com', '', '', 14, 'static_image/logo1.jpg');
/*!40000 ALTER TABLE `user_data` ENABLE KEYS */;

-- Dumping structure for table licienta.user_right
CREATE TABLE IF NOT EXISTS `user_right` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `right` set('user','admin') NOT NULL DEFAULT 'user',
  `redirect` varchar(50) NOT NULL DEFAULT 'dashboard.php',
  `id_user` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_user` (`id_user`),
  CONSTRAINT `FK_user_right_user` FOREIGN KEY (`id_user`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

-- Dumping data for table licienta.user_right: ~12 rows (approximately)
/*!40000 ALTER TABLE `user_right` DISABLE KEYS */;
REPLACE INTO `user_right` (`id`, `right`, `redirect`, `id_user`) VALUES
	(1, 'user', 'dashboard.php', 2),
	(2, 'admin', 'dashboard.php', 1),
	(4, 'user', 'dashboardu.php', 4),
	(5, 'user', 'dashboardu.php', 5),
	(7, 'user', 'dashboard.php', 7),
	(8, 'user', 'dashboard.php', 8),
	(9, 'user', 'dashboard.php', 9),
	(10, 'user', 'dashboard.php', 10),
	(11, 'user', 'dashboard.php', 11),
	(12, 'user', 'dashboard.php', 12),
	(13, 'user', 'dashboard.php', 13),
	(14, 'user', 'dashboard.php', 14);
/*!40000 ALTER TABLE `user_right` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
